/*let value = 0

setInterval(() => {
    value += 1
    if(value > 1) value = 0

    transformStatus(value)
}, 3000)*/
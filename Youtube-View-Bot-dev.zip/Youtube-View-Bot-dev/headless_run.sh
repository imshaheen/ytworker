#!/bin/bash

node --max-old-space-size=8192 ./main/server.js
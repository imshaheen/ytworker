#!/bin/bash

npm install
npm install electron --global

cd ./main/
npm run build
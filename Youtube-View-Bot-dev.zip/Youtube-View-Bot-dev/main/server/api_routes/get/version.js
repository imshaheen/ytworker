module.exports = (req, res) => {
    res.json(server_version)
}
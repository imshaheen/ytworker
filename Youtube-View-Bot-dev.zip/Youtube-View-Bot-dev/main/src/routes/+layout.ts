export const prerender = "auto"
export const ssr = false
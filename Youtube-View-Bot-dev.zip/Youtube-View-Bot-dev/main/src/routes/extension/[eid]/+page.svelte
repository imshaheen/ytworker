<script lang="ts">
    let extensionId = new URL(window.location.href).pathname.split("/").pop()
    console.log(extensionId)
</script>
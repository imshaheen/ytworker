#!/bin/bash

electron --disable-gpu --js-flags=--max-old-space-size=8192 ./index.js